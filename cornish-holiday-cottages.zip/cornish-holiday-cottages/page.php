<?php /* Template Name: Default Page Template */ ?>
<?php get_header(); ?>
<main id="content" role="main">
	
<div class="entry-content" itemprop="mainContentOfPage">
<?php the_content(); ?>
</div>

</main>
<?php get_footer(); ?>
