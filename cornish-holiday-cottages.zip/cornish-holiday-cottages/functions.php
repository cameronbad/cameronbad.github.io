<?php
add_action( 'after_setup_theme', 'ws350074Theme_setup' );
function ws350074Theme_setup() {
load_theme_textdomain( 'ws350074Theme', get_template_directory() . '/languages' );
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'responsive-embeds' );
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'html5', array( 'search-form' ) );
add_theme_support( 'woocommerce' );
global $content_width;
if ( !isset( $content_width ) ) { $content_width = 1920; }
register_nav_menus( array( 'main-menu' => esc_html__( 'Main Menu', 'ws350074Theme' ) ) );
}
add_action( 'wp_enqueue_scripts', 'ws350074Theme_enqueue' );
function ws350074Theme_enqueue() {
wp_enqueue_style( 'ws350074Theme-style', get_stylesheet_uri() );
wp_enqueue_script( 'jquery' );
}
add_action( 'wp_footer', 'ws350074Theme_footer' );
function ws350074Theme_footer() {
?>
<script>
jQuery(document).ready(function($) {
var deviceAgent = navigator.userAgent.toLowerCase();
if (deviceAgent.match(/(iphone|ipod|ipad)/)) {
$("html").addClass("ios");
}
if (navigator.userAgent.search("MSIE") >= 0) {
$("html").addClass("ie");
}
else if (navigator.userAgent.search("Chrome") >= 0) {
$("html").addClass("chrome");
}
else if (navigator.userAgent.search("Firefox") >= 0) {
$("html").addClass("firefox");
}
else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
$("html").addClass("safari");
}
else if (navigator.userAgent.search("Opera") >= 0) {
$("html").addClass("opera");
}
});
</script>
<?php
}
add_filter( 'document_title_separator', 'ws350074Theme_document_title_separator' );
function ws350074Theme_document_title_separator( $sep ) {
$sep = '|';
return $sep;
}
add_filter( 'the_title', 'ws350074Theme_title' );
function ws350074Theme_title( $title ) {
if ( $title == '' ) {
return '...';
} else {
return $title;
}
}
add_filter( 'nav_menu_link_attributes', 'ws350074Theme_schema_url', 10 );
function ws350074Theme_schema_url( $atts ) {
$atts['itemprop'] = 'url';
return $atts;
}
if ( !function_exists( 'ws350074Theme_wp_body_open' ) ) {
function ws350074Theme_wp_body_open() {
do_action( 'wp_body_open' );
}
}
add_action( 'wp_body_open', 'ws350074Theme_skip_link', 5 );
function ws350074Theme_skip_link() {
echo '<a href="#content" class="skip-link screen-reader-text">' . esc_html__( 'Skip to the content', 'ws350074Theme' ) . '</a>';
}
add_filter( 'the_content_more_link', 'ws350074Theme_read_more_link' );
function ws350074Theme_read_more_link() {
if ( !is_admin() ) {
return ' <a href="' . esc_url( get_permalink() ) . '" class="more-link">' . sprintf( __( '...%s', 'ws350074Theme' ), '<span class="screen-reader-text">  ' . esc_html( get_the_title() ) . '</span>' ) . '</a>';
}
}
add_filter( 'excerpt_more', 'ws350074Theme_excerpt_read_more_link' );
function ws350074Theme_excerpt_read_more_link( $more ) {
if ( !is_admin() ) {
global $post;
return ' <a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="more-link">' . sprintf( __( '...%s', 'ws350074Theme' ), '<span class="screen-reader-text">  ' . esc_html( get_the_title() ) . '</span>' ) . '</a>';
}
}
add_filter( 'big_image_size_threshold', '__return_false' );
add_filter( 'intermediate_image_sizes_advanced', 'ws350074Theme_image_insert_override' );
function ws350074Theme_image_insert_override( $sizes ) {
unset( $sizes['medium_large'] );
unset( $sizes['1536x1536'] );
unset( $sizes['2048x2048'] );
return $sizes;
}
add_action( 'widgets_init', 'ws350074Theme_widgets_init' );
function ws350074Theme_widgets_init() {
register_sidebar( array(
'name' => esc_html__( 'Sidebar Widget Area', 'ws350074Theme' ),
'id' => 'primary-widget-area',
'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
'after_widget' => '</li>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
}
add_action( 'wp_head', 'ws350074Theme_pingback_header' );
function ws350074Theme_pingback_header() {
if ( is_singular() && pings_open() ) {
printf( '<link rel="pingback" href="%s" />' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
}
}
add_action( 'comment_form_before', 'ws350074Theme_enqueue_comment_reply_script' );
function ws350074Theme_enqueue_comment_reply_script() {
if ( get_option( 'thread_comments' ) ) {
wp_enqueue_script( 'comment-reply' );
}
}
function ws350074Theme_custom_pings( $comment ) {
?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>"><?php echo esc_url( comment_author_link() ); ?></li>
<?php
}
add_filter( 'get_comments_number', 'ws350074Theme_comment_count', 0 );
function ws350074Theme_comment_count( $count ) {
if ( !is_admin() ) {
global $id;
$get_comments = get_comments( 'status=approve&post_id=' . $id );
$comments_by_type = separate_comments( $get_comments );
return count( $comments_by_type['comment'] );
} else {
return $count;
}
}
/**
 * Font Awesome Kit Setup
 *
 * This will the Font Awesome Kit to the front-end, the admin back-end,
 * and the login screen area.
 */
if (! function_exists('fa_custom_setup_kit') ) {
  function fa_custom_setup_kit($kit_url = '') {
    foreach ( [ 'wp_enqueue_scripts', 'admin_enqueue_scripts', 'login_enqueue_scripts' ] as $action ) {
      add_action(
        $action,
        function () use ( $kit_url ) {
          wp_enqueue_script( 'font-awesome-kit', $kit_url, [], null );
        }
      );
    }
  }
}
fa_custom_setup_kit('https://kit.fontawesome.com/a3b46c02f6.js');

/* Gets the id of all pages using the specified template */
function get_page_by_template($template = '') {
  $args = array(
    'meta_key' => '_wp_page_template',
    'meta_value' => $template
  );
  return get_pages($args); 
}

add_action( 'after_setup_theme', 'ACF_setup' );
function ACF_setup() {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	// Check if ACF PRO is active
	if ( is_plugin_active( 'advanced-custom-fields-pro/acf.php' ) ) {
		// Abort all bundling, ACF PRO plugin takes priority
		return;
	}
	
	if ( defined( 'MY_ACF_PATH' ) ) {
		return;
	}
	
	// Define path and URL to the ACF plugin.
	define( 'MY_ACF_PATH', get_stylesheet_directory() . '/includes/acf/' );
	define( 'MY_ACF_URL', get_stylesheet_directory_uri() . '/includes/acf/' );
	
	// Include the ACF plugin.
	include_once( MY_ACF_PATH . 'acf.php' );

	// Customize the URL setting to fix incorrect asset URLs.
	add_filter('acf/settings/url', 'my_acf_settings_url');
	function my_acf_settings_url( $url ) {
		return MY_ACF_URL;
	}
}

add_action( 'after_setup_theme', 'ACF_setup' );
function ACF_check() {
	// Check if the ACF free plugin is activated
	if ( is_plugin_active( 'advanced-custom-fields/acf.php' ) ) {
		// Free plugin activated
		// Free plugin activated, show notice
		add_action( 'admin_notices', function () {
			?>
			<div class="updated" style="border-left: 4px solid #ffba00;">
				<p>The ACF plugin cannot be activated at the same time as Cornish Holiday Homes and has been deactivated. Please keep ACF installed to allow you to use ACF functionality.</p>
			</div>
			<?php
		}, 99 );

		// Disable ACF free plugin
		deactivate_plugins( 'advanced-custom-fields/acf.php' );
	}

	// Check if ACF free is installed
	if ( ! file_exists( WP_PLUGIN_DIR . '/advanced-custom-fields/acf.php' ) ) {
		// Free plugin not installed
		// Hide the ACF admin menu item.
		add_filter( 'acf/settings/show_admin', '__return_false' );
		// Hide the ACF Updates menu
		add_filter( 'acf/settings/show_updates', '__return_false', 100 );
	}
}


function my_acf_json_save_point( $path ) {
    return get_stylesheet_directory() . '/includes/acf-json';
}
add_filter( 'acf/settings/save_json', 'my_acf_json_save_point' );

function my_acf_json_load_point( $paths ) {
    // Remove the original path (optional).
    unset($paths[0]);

    // Append the new path and return it.
    $paths[] = get_stylesheet_directory() . '/includes/acf-json';

    return $paths;    
}
add_filter( 'acf/settings/load_json', 'my_acf_json_load_point' );

require_once get_template_directory() . '/includes/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'ws350074Theme_register_required_plugins' );
function ws350074Theme_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(
		array(
			'name'      => 'Site Reviews',
			'slug'      => 'site-reviews',
			'required'  => true,
		),
		array(
			'name'      => 'Smart Slider 3',
			'slug'      => 'smart-slider-3',
			'required'  => true,
		),
				array(
			'name'      => 'White Label CMS',
			'slug'      => 'white-label-cms',
			'required'  => true,
		),
				array(
			'name'      => 'WPForms Lite',
			'slug'      => 'wpforms-lite',
			'required'  => true,
		),
	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'ws350074Theme',         // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );
}
