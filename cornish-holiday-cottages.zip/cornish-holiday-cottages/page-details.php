<?php /* Template Name: Property Details Page Template */ ?>
<?php get_header(); ?>
<?php 	$features = get_field('additional_features'); //Array
 	  	$pages = get_page_by_template('page-details.php');
	  	shuffle($pages);
?>
<main id="content" role="main">
	<div class="entry-content" itemprop="mainContentOfPage">
		<?php the_content(); ?> <!-- Images -->
		
		<h2 class="detail-head"> <?= get_field('property_name') ?> </h2>
		<h3 class="detail-sub"> <?= get_field('location') ?> </h3> <!-- Subheader -->
		
		<div class="features flex-row detail-row">
			<div class="feature">
				<i class="fa-solid fa-person" title="Capacity"></i>
				<span>Capacity: <?= get_field('capacity') ?></span>
			</div>
			<?php			
				foreach($features as $feature) {
					echo '<div class="feature">';
					echo '<i class="' . $feature['value'] . '"></i>';
					echo '<span>' . $feature['label'] . '</span>';
					echo '</div>';
				}	
			?>		
		</div>
		<div class="detail-row">
			<h3>Local Area: </h3>
			<p><?= get_field('local_area') ?></p>
		</div>
		<div class="detail-row">
			<h3>Description: </h3>
			<p><?= get_field('description') ?></p>
		</div>
		<!-- Page Links -->
		<h3>Other properties: </h3>
		<div class="detail-row properties-list flex-row">
			<?php foreach(array_slice($pages, 0, 3) as $page) {
				$features = get_field('additional_features', $page); //Array
				echo '<div class="property flex-column">';
				echo '<h1>' . get_field('property_name', $page) . '</h1>';
				echo '<img src="' . get_field('highlight_photo', $page) . '" alt="' . get_field('property_name', $page) . '">';
				echo '<div class="property-row flex-row">';
				echo '<div>' . get_field('location', $page) . '</div>';
				echo '<div>' . get_field('capacity', $page) . '<i class="fa-solid fa-person" title="Capacity"></i></div>';
				echo '</div>';
				echo '<div class="features">';
				foreach($features as $feature) {
					echo '<i class="' . $feature['value'] . '" title="' . $feature['label'] . '"></i>';
				}
				echo '</div>';
				echo '<a href="' . get_page_link($page) . '"></a>';
				echo '</div>';
			}?>
		</div>
		<!-- Reviews -->
		<div class="detail-row">
			<h3>Reviews: </h3>
			<?php
				echo do_shortcode('[site_reviews assigned_posts="post_id"]');
				echo do_shortcode('[site_reviews_form assigned_posts="post_id"]');
			?>
		</div>
	</div>
	


</main>
<?php get_footer(); ?>
