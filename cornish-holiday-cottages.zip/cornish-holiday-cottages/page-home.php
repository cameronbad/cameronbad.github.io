<?php /* Template Name: Holiday Home Page */ ?>
<?php get_header(); ?>

<main id="content" role="main">
	
<?php
echo do_shortcode('[smartslider3 slider="2"]');
?>
<div class="mid_box">
	<div class="mid_bg">
		Rent Now!
	</div>
</div>
	
<div class="entry-content">
	<?php the_content(); ?>
</div>

</main>
<?php get_footer(); ?>
