</div>
<div class="spacer"></div>
<footer id="footer" role="contentinfo">
<?php $privacy_page = get_post(6); ?>
<a href="<?php echo get_permalink($privacy_page->ID); ?>"><span><?php echo $privacy_page->post_title; ?></span></a>
<div id="copyright">
&copy; <?php echo esc_html( date_i18n( __( 'Y', 'ws350074Theme' ) ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
</div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>