<?php /* Template Name: Properties Page Template */ ?>
<?php get_header(); ?>
<?php $pages = get_page_by_template('page-details.php');?>
<main id="content" role="main">
	<?php the_content(); ?>
	
	<div class="properties-list flex-row">
		<?php foreach($pages as $page) {
			$features = get_field('additional_features', $page); //Array
			echo '<div class="property flex-column">';
			echo '<h1>' . get_field('property_name', $page) . '</h1>';
			echo '<img src="' . get_field('highlight_photo', $page) . '" alt="' . get_field('property_name', $page) . '">';
			echo '<div class="property-row flex-row">';
			echo '<div>' . get_field('location', $page) . '</div>';
			echo '<div>' . get_field('capacity', $page) . '<i class="fa-solid fa-person" title="Capacity"></i></div>';
			echo '</div>';
			echo '<div class="features">';
			foreach($features as $feature) {
				echo '<i class="' . $feature['value'] . '" title="' . $feature['label'] . '"></i>';
			}
			echo '</div>';
			echo '<a href="' . get_page_link($page) . '"></a>';
			echo '</div>';
		}?>
	</div>

</main>
<?php get_footer(); ?>
